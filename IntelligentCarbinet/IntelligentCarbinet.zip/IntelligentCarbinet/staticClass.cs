﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PublicConfig
{
    public static class staticClass
    {
        public static DateTime timeBase = DateTime.Now;
        public static string PicturePath = @"商品图片\";
    }
}
