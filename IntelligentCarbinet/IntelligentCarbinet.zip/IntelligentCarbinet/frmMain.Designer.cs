﻿namespace IntelligentCarbinet
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.产品监控ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.产品设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.产品参数设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.货架产品监控ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.缺货监控ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.产品监控ToolStripMenuItem,
            this.产品设置ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(679, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 产品监控ToolStripMenuItem
            // 
            this.产品监控ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.货架产品监控ToolStripMenuItem,
            this.缺货监控ToolStripMenuItem});
            this.产品监控ToolStripMenuItem.Name = "产品监控ToolStripMenuItem";
            this.产品监控ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.产品监控ToolStripMenuItem.Text = "产品监控";
            // 
            // 产品设置ToolStripMenuItem
            // 
            this.产品设置ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.产品参数设置ToolStripMenuItem});
            this.产品设置ToolStripMenuItem.Name = "产品设置ToolStripMenuItem";
            this.产品设置ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.产品设置ToolStripMenuItem.Text = "产品设置";
            // 
            // 产品参数设置ToolStripMenuItem
            // 
            this.产品参数设置ToolStripMenuItem.Name = "产品参数设置ToolStripMenuItem";
            this.产品参数设置ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.产品参数设置ToolStripMenuItem.Text = "产品参数设置";
            this.产品参数设置ToolStripMenuItem.Click += new System.EventHandler(this.产品参数设置ToolStripMenuItem_Click);
            // 
            // 货架产品监控ToolStripMenuItem
            // 
            this.货架产品监控ToolStripMenuItem.Name = "货架产品监控ToolStripMenuItem";
            this.货架产品监控ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.货架产品监控ToolStripMenuItem.Text = "货架产品监控";
            this.货架产品监控ToolStripMenuItem.Click += new System.EventHandler(this.货架产品监控ToolStripMenuItem_Click);
            // 
            // 缺货监控ToolStripMenuItem
            // 
            this.缺货监控ToolStripMenuItem.Name = "缺货监控ToolStripMenuItem";
            this.缺货监控ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.缺货监控ToolStripMenuItem.Text = "缺货监控";
            this.缺货监控ToolStripMenuItem.Click += new System.EventHandler(this.缺货监控ToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(679, 468);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "智能货架";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 产品监控ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 产品设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 产品参数设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 货架产品监控ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 缺货监控ToolStripMenuItem;
    }
}