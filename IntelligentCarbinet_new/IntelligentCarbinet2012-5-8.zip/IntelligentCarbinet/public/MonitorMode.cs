﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IntelligentCarbinet
{
    public enum MonitorMode
    {
        防盗模式,
        讲解模式
    }
}
